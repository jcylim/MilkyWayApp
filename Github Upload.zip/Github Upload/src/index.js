/**
 * Sample React Native App
 * https://github.com/facebook/react-native
 * @flow
 */

import React, { Component } from 'react';
import MilkyWayStack from './config/router';
import Login from './Login/login';
import Register from './SignUp/register';
import Explore from './Main/explore';

export default class MilkyWayApp extends Component {
  render() {
    return (
      <MilkyWayStack />
    );
  }
}

//export default MilkyWayApp;

/*const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#F5FCFF',
  },
  welcome: {
    fontSize: 20,
    textAlign: 'center',
    margin: 10,
  },
  instructions: {
    textAlign: 'center',
    color: '#333333',
    marginBottom: 5,
  },
});*/