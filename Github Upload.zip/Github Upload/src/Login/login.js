import React, { Component } from 'react';
import { View, Text, StyleSheet, Image, KeyboardAvoidingView, TextInput, TouchableOpacity, Platform, BackHandler, ToastAndroid} from 'react-native';
import LoginForm from './loginForm';
import FBSDK, { LoginManager, AccessToken, LoginButton, GraphRequest, GraphRequestManager } from 'react-native-fbsdk';

let listener = null

export default class Login extends Component {
	constructor(props) {
		super(props);
		this.sendDataToServer = this.sendDataToServer.bind(this);
		this.storeUserInfo = this.storeUserInfo.bind(this);
		this._fbAuth = this._fbAuth.bind(this);
		this.states = {
			firstName: '',
			lastName: '',
			email: '',
			userName: '',
			profilePic: ''
		};
	}

	_responseInfoCallback(error: ?Object, result: ?Object) {
		if (error) {
		  alert('Error fetching data: ' + error.toString());
		} else {
		  alert('Success fetching data: ' + result.toString());
		}
	}

	_fbAuth() {
		LoginManager.logInWithReadPermissions(['public_profile']).then(function(result) {
			if (result.isCancelled) {
				console.log('Login was cancelled');
			} else {
				console.log('Login was a success ' + result.grantedPermissions.toString());
				AccessToken.getCurrentAccessToken().then((data) => {
	          		const { accessToken } = data
	          		this.storeUserInfo(data)
	          		/*const infoRequest = new GraphRequest(
	                '/me',
	                {
	                  accessToken: accessToken,
	                  parameters: {
	                    fields: {
	                      string: 'email,name,first_name,middle_name,last_name'
	                    }
	                  }
	                },
	                this._responseInfoCallback
	              );
	              // Start the graph request.
	              new GraphRequestManager().addRequest(infoRequest).start()
	              console.log('request finished');*/
        		})
        		this.sendDataToServer;
			}
		}, function(error) {
			console.log('An error occured' + error);
		})
	}

	sendDataToServer() {
		/*try {
    		let response = await fetch('http://milkywayapp.me:8080/api/auth/signin', {
		    	method: 'POST',
		    	headers: {
		    		'Accept': 'application/json',
		    		'Content-Type': 'application/json'
		    	},
		    	body: JSON.stringify({
		    		firstName: this.states.firstName,
		    		lastName: this.states.lastName,
		    		username: this.states.userName,
		    		email: this.states.email,
		    		password: 'MilkyWay08/05'
		    	})
    		});
    		let res = await response.json();
    		if (response.status == 400) {
    			this.props.navigation.navigate('Explore');
    		}
    		else {
    			ToastAndroid.show(res['message'], ToastAndroid.LONG); 
    		}
    	} catch(errors) {
		    // Handle error
		}*/
		//this.props.navigation.navigate('Explore');
		console.log('in sendDataToServer');
  	}

	componentDidMount() {
	    if (Platform.OS == "android" && listener == null) {
	      listener = BackHandler.addEventListener("hardwareBackPress", () => {
	        return false
	      })
	    }
  	}

	signUp = () => {
		this.props.navigation.navigate('Register');
	};

	storeUserInfo(token) {
		console.log('im in')
		fetch('https://graph.facebook.com/v2.5/me?fields=email,name,friends&access_token=' + token)
			.then((response) => response.json())
			.then((res) => {
			  this.states.firstName = res.first_name
			  this.states.lastName = res.last_name
			  this.states.userName = res.id
			  this.states.email = res.email
			  this.states.profilePic = setAvatar(res.id)      
			})
			.catch(() => {
			  reject('Unable to fetch data from FB')
			})
		console.log('im out')
	}

	render() {
		return (
			<View style={styles.container}>
				<View style={styles.viewContainer}>
					<Image
						style={styles.logo}
						source={require('../images/logo_white.png')}
						resizeMode='contain'
					/>
				</View>
				<View style={styles.formContainer}>
					<View style={styles.inputContainer}>
						<TextInput
							placeholder='Username or Email'
							style={styles.input}
							keyboardType='email-address'
							autoCapitalize='none'
							//autoCorrect={false}
						/>
						<TextInput 
							placeholder='Password'
							style={styles.input}
							secureTextEntry
						/>
					</View>
					<View  style={styles.loginContainer}>
						<TouchableOpacity style={styles.login}>
							<Text>LOGIN</Text>
						</TouchableOpacity>
					</View>
					<View style={styles.extraContainer}>
						<View style={styles.apiViewContainer}>
							<TouchableOpacity style={styles.apiContainer} onPress={this._fbAuth}>
								<Text style={{color: 'white'}}>Continue with Facebook</Text>
							</TouchableOpacity>
						</View>
						<View style={styles.textContainer}>
							<Text style={styles.text}>New to MilkyWay? </Text>
							<TouchableOpacity style={styles.signUpContainer} onPress={this.signUp}>
								<Text style={styles.signUp}>Sign Up</Text>
							</TouchableOpacity>
						</View>
					</View>
				</View>
			</View>
		);
	}
}

const styles = StyleSheet.create({
	container: {
		flex: 1,
	},
	logo: {
		width: 170,
		height: 170
	}, 
	viewContainer: {
		justifyContent: 'center',
		flex: 1,
		alignItems: 'center',
		backgroundColor: '#800080'
	},
	formContainer: {
		backgroundColor: '#800080',
		flex: 1
	},
	title: {
		color: 'white',
		fontSize: 35,
		fontWeight: 'bold'
	},
	input: {
		height: 50,
		width: 300,
		opacity: 0.9,
		color: 'white'
	},
	inputContainer: {
		flex: 1,
		justifyContent: 'flex-start',
		alignItems: 'center',
	},
	login: {
		width: 200,
		height: 40,
		backgroundColor: 'white',
		borderRadius: 10,
		justifyContent: 'center',
		alignItems: 'center',
	},
	loginContainer: {
		flex: 1,
		justifyContent: 'flex-start',
		alignItems: 'center',
	},
	signUp: {
		color: 'white',
		fontSize: 15,
		textDecorationLine: 'underline'
	},
	fbText: {
		color: 'white',
		fontSize: 15,
	},
	text: {
		color: 'white',
		fontSize: 15,
	},
	signUpContainer: {
		justifyContent: 'center',
		alignItems: 'flex-end',
	},
	extraContainer: {
		flex: 1,
	},
	textContainer: {
		flex: 1,
		paddingVertical: 10,
		flexDirection: 'row',
		justifyContent: 'center',
		alignItems: 'flex-end',
	},
	apiViewContainer: {
		flex: 4,
		alignItems: 'center',
		justifyContent: 'flex-end'
	},
	apiContainer: {
		width: 180,
		height: 40,
		backgroundColor: '#3b5998',
		borderRadius: 10,
		justifyContent: 'center',
		alignItems: 'center',
	}
});

//export default Login;

